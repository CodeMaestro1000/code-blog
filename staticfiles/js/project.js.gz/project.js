const navbar = document.querySelector(".navbar");
navbar.classList.remove("navbar-sticky");
navbar.classList.add("navbar-relative");
